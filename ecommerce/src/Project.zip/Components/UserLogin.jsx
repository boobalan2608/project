import { useState } from "react";
import { Link } from 'react-router-dom';
import '../Styles/UserLogin.css';   
const UserLogin = ()=> {
    let [username, setUsername] = useState("");
    let [password, setPassword] = useState("");
    console.log(username);
    console.log(password);

    function verify() {
        if (username === "bala" && password === "007") {
            alert("Login Success");
        }
        else {
            alert("Invalid Credits");
        }
    }
    return (
        <div className="user-login">
            <h1 className="user-title">User Login Page</h1>
            <div className="user-login-form-cont">
                <form action="" className="user-login-form">
                    <label>User Name: </label>
                    <input type="text" onChange={(e) => { setUsername(e.target.value) }} className="user-name" placeholder="Enter the Name" />
                    <label htmlFor="">Password: </label>
                    <input type="text" onChange={(e) => { setPassword(e.target.value) }} className="user-pass" placeholder="Enter the Password"/>
                    <button onClick={verify} className="submit-btn">Login</button>
                </form>
            </div>
                <h5>Login as Admin?  <Link to="../UserSignup">click here</Link></h5>
        </div>
    ); 
}
 
export default UserLogin;