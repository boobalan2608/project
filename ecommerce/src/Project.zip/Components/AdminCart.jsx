import React from 'react'

export default function AdminCart() {
  return (
    <div style={{height:"78.8vh"}}><h3 style={{textAlign:"center"}}>AdminCart Will be Shown here</h3></div>
  )
}
