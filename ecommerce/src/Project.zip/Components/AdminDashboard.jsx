import React from 'react'

export default function AdminDashboard() {
  return (
    <div style={{height:"78.8vh"}}><h3 style={{textAlign:"center"}}>AdminDashboard</h3></div>
  )
}
