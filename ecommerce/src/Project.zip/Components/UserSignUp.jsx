import { useEffect, useState } from "react";
import { Link } from 'react-router-dom';
import '../Styles/UserSignUp.css';
import axios from 'axios';
// import { Button } from "bootstrap";
const UserSignUp = () => {
    let [adminName, setAdminname] = useState("");
    let [password, setPassword] = useState("");
    let [name, setName] = useState("");
    console.log(adminName);
    console.log(password);
    let data = {adminName,password,name};
    function AddAdminData(){
        axios.post("http://localhost:1212/AdminInfo",data)
        .then((res)=>{
            alert("Admin Added Successfully")
        })
        .catch((err)=>{
            alert(err);
        })
    }
    return (
        <div className="user-signup">
            <h1 className="user-title">User SignUp Page</h1>


            <div className="user-signup-form-cont">
                <form action=""  onSubmit={AddAdminData} className="user-signup-form">
                    <label>Admin Name: </label>
                    <input type="text" onChange={(e) => { setAdminname(e.target.value) }} className="user-username" placeholder="Enter the UserName" required/>
                    <label htmlFor="">Name: </label>
                    <input type="text" onChange={(e) => { setName(e.target.value) }} className="user-name" placeholder="Enter the Name" required/>
                    <label htmlFor="">Password: </label>
                    <input type="text" onChange={(e) => { setPassword(e.target.value) }} className="user-pass" placeholder="Enter the Password" required/>
                    <button className="submit-btn">Sign up</button>
                </form>
            </div>
            <h5>Already have an account?  <Link to="../Login">Sign in</Link></h5>

        </div>
    );
}

export default UserSignUp;