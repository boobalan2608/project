import { useEffect, useState } from "react";
import { Link } from 'react-router-dom';
import '../Styles/AdminLogin.css';
const AdminLogin = () => {
    let [adminname, setAdminname] = useState("");
    let [password, setPassword] = useState("");
    let [Admindata, setAdminData] = useState([]);
    console.log(adminname);
    console.log(password);
    useEffect(()=>{
        async function fetchAdminData() {
            let res = await fetch("http://localhost:1212/AdminInfo");
            let data = await res.json();
            setAdminData(data);
        }
        fetchAdminData();
    },[])
    return (
        <div className="admin-login">
            <h1 className="admin-title">Admin Login Page</h1>


            <div className="login-form-cont">
                <form action="" className="admin-login-form">
                    <label>Admin Name: </label>
                    <input type="text" onChange={(e) => { setAdminname(e.target.value);console.log(e);
                     }} className="admin-name" placeholder="Enter the Name"/>
                    <label htmlFor="">Password: </label>
                    <input type="text" onChange={(e) => { setPassword(e.target.value) }} className="amdin-pass" placeholder="Enter the Password"/>
                    <button className="submit-btn">Login</button>
                </form>
            </div>
            <h5>Login as User?  <Link to="../UserLogin">click here</Link></h5>

        </div>
    ); 
}

export default AdminLogin;